<?php

namespace App\Http\Controllers;

use App\Http\Resources\VanCollection;
use App\Http\Resources\VanResource;
use App\Models\Van;
use Illuminate\Http\Request;

class VanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return new VanCollection(Van::all());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            $van_data = $request->only(['type', 'name', 'price', 'description', 'user_id']);
            $Van = Van::firstOrCreate(array_merge($van_data, ["image" => ""]));

            $image = $request->file('image');
            $file_name = $Van->id . '.' . $image->getClientOriginalExtension();
            $image->storeAs("public/images/vans/", $file_name);

            $Van->update(['image' => $file_name]);

            return response()->json(["status" => "Success"], 200);
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Van  $van
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return new VanResource(Van::find($id));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Van  $van
     * @return \Illuminate\Http\Response
     */
    public function edit(Van $van)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Van  $van
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Van $van)
    {
        try {
            $van->update($request->only(['type', 'name', 'price', 'description', 'user_id']));

            if ($request->has("image")) {
                $image = $request->file('image');
                $file_name = $van->id . '.' . $image->getClientOriginalExtension();
                $image->storeAs("public/images/vans/", $file_name);

                $van->update(['image' => $file_name]);
            }

            return response()->json(["status" => "Success", "van" => $van], 200);
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Van  $van
     * @return \Illuminate\Http\Response
     */
    public function destroy(Van $van)
    {
        $van->delete();
    }
}
