<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            // Authentication successful
            $user = Auth::user();
            $token = $user->createToken('authToken')->plainTextToken;
            return response()->json([
                'user' => $user,
                'token' => $token
            ]);
        } else {
            // Authentication failed
            return response()->json(['error' => 'Invalid credentials'], 401);
        }
    }

    public function Register(Request $request)
    {
        try {
            $user_data = $request->only(['first_name', 'last_name', 'email', 'password']);
            $user_data['password'] = Hash::make($user_data['password']);
            User::validate_user($user_data['email']);
            $user = User::firstOrCreate($user_data);

            $profile_image = $request->file('profileImage');
            $file_name = $user->id . '.' . $profile_image->getClientOriginalExtension();
            $profile_image->storeAs("public/images/users/", $file_name);

            $user->update(['picture' => $file_name]);
            $token = $user->createToken('authToken')->plainTextToken;

            return response()->json([
                'user' => $user,
                'token' => $token
            ]);
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 400);
        }
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'Logged out']);
    }
}
